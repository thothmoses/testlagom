## Running the sample code

1. Start a first node:

    ```
    sbt -Dconfig.resource=local1.conf run
    ```

2. Start `shopping-cart-service` and add item to cart

3. Notice the log output in the terminal of the `shopping-analytics-service`
